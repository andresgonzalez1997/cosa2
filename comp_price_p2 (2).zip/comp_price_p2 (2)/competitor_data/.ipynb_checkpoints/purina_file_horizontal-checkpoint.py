import fitz  # PyMuPDF
import datetime
import re
import pandas as pd

# --------------------------------------------------------------------------------
# 0) Esquema de columnas y tipos
# --------------------------------------------------------------------------------
SCHEMA = {
    "product_number": "string",
    "formula_code": "string",
    "product_name": "string",
    "product_form": "string",
    "unit_weight": "double",
    "pallet_quantity": "double",
    "stocking_status": "string",
    "min_order_quantity": "double",
    "days_lead_time": "double",
    "fob_or_dlv": "string",
    "price_change": "double",
    "list_price": "double",
    "full_pallet_price": "double",
    "half_load_full_pallet_price": "double",
    "full_load_full_pallet_price": "double",
    "full_load_best_price": "double",
    "plant_location": "string",
    "date_inserted": "string",
    "source": "string",
}
SCHEMA_COLS   = list(SCHEMA.keys())
NUMERIC_COLS  = [c for c,t in SCHEMA.items() if t == "double"]

# --------------------------------------------------------------------------------
# 1) Funciones para fecha y ubicación (zona superior página 1)
# --------------------------------------------------------------------------------

def effective_date(file_path):
    """
    Extrae fecha (p.ej. 10/07/2024 → '2024-10-07') desde y=50..130 pt de la página 1.
    """
    try:
        doc  = fitz.open(file_path)
        page = doc.load_page(0)
        area = fitz.Rect(0,  50, page.rect.width, 130)
        text = page.get_text("text", clip=area)
        m = re.search(r"\b\d{1,2}/\d{1,2}/(?:\d{4}|\d{2})\b", text)
        if not m:
            return None
        date_str = m.group(0)
        for fmt in ("%m/%d/%Y", "%m/%d/%y"):
            try:
                return datetime.datetime.strptime(date_str, fmt).date().strftime("%Y-%m-%d")
            except ValueError:
                continue
    except Exception:
        pass
    return None

def plant_location(file_path):
    """
    Extrae ubicación (p.ej. "HUDSON'S") desde y=0..50 pt de la página 1.
    """
    try:
        doc  = fitz.open(file_path)
        page = doc.load_page(0)
        area = fitz.Rect(0, 0, page.rect.width, 50)
        text = page.get_text("text", clip=area).upper()
        if "HUDSON'S" in text:
            return "HUDSON'S"
        first = text.split("\n")[0].strip()
        return first.replace(",", "").strip()
    except Exception:
        return None

# --------------------------------------------------------------------------------
# 2) Extracción de la “tabla” de todas las páginas (texto libre + split)
# --------------------------------------------------------------------------------

def extract_main_table(file_path, header_offset=100):
    """
    - Recorta cada página entre y=header_offset..final.
    - Toma línea a línea y hace split por 2+ espacios.
    - Salta cualquier línea vacía o que contenga el encabezado PDF.
    - Normaliza a len(SCHEMA_COLS) columnas.
    - Devuelve [DataFrame] listo para concatenar.
    """
    rows = []
    doc = fitz.open(file_path)

    for page in doc:
        clip = fitz.Rect(0, header_offset, page.rect.width, page.rect.height)
        text = page.get_text("text", clip=clip)
        for line in text.split("\n"):
            line = line.strip()
            if not line:
                continue
            # evita repetir el header si aparece en cada página
            if re.match(r"^\s*product\s+number", line, re.IGNORECASE):
                continue
            cols = re.split(r"\s{2,}", line)
            rows.append(cols)

    if not rows:
        return []

    # normalizamos cada fila al número de columnas del esquema
    n_cols = len(SCHEMA_COLS)
    data = []
    for r in rows:
        if len(r) < n_cols:
            r = r + [""] * (n_cols - len(r))
        elif len(r) > n_cols:
            # agrupa el exceso en la última columna
            r = r[:n_cols-1] + [" ".join(r[n_cols-1:])]
        data.append(r)

    # construye DataFrame usando exactamente los nombres del esquema
    df = pd.DataFrame(data, columns=SCHEMA_COLS)
    return [df]

# --------------------------------------------------------------------------------
# 3) Corrección de valores negativos
# --------------------------------------------------------------------------------

def correct_negative_value(value):
    """
    "100-" → -100.0 ; intento también float("123") → 123.0
    """
    txt = str(value).strip()
    if txt.endswith("-"):
        try:
            return -float(txt[:-1])
        except ValueError:
            return value
    try:
        return float(txt)
    except ValueError:
        return value

# --------------------------------------------------------------------------------
# 4) Función principal: unifica, limpia y ajusta tipos
# --------------------------------------------------------------------------------

def read_file(file_path):
    # a) extraer
    tables = extract_main_table(file_path)
    if not tables:
        print("[WARN] No se extrajo tabla; devolviendo vacío.")
        return pd.DataFrame({
            col: pd.Series(dtype="float" if SCHEMA[col]=="double" else "object")
            for col in SCHEMA_COLS
        })

    # b) concatenar
    df = pd.concat(tables, ignore_index=True)

    # c) limpiar negativos
    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = df[col].apply(correct_negative_value)

    # d) asegurar columnas del esquema y tipos
    for col, typ in SCHEMA.items():
        if col not in df.columns:
            df[col] = pd.Series(dtype="float" if typ=="double" else "object")
        else:
            if typ == "double":
                df[col] = pd.to_numeric(df[col], errors="coerce")
            else:
                df[col] = df[col].astype(str)

    # e) agregar metadatos
    df["plant_location"] = plant_location(file_path) or ""
    df["date_inserted"]  = effective_date(file_path) or ""
    df["source"]         = "pdf"

    # f) reordenar
    return df[SCHEMA_COLS]

# --------------------------------------------------------------------------------
