from __future__ import annotations
"""
purina_pdf_reader.py – capturar tablas Statesville sin perder la primera fila
=============================================================================
• Conservar la **primera línea de datos** de cada página.
• Eliminar cabeceras repetidas (“PRODUCT NUMBER …”), fragmentos (“MIN / DAYS”)
  y textos sueltos como “Price / Unit” o “Price in US Dollars”.
• Corregir números negativos (100‑  →  ‑100) y añadir metadatos.
"""
import datetime as _dt
import pathlib
import re
from typing import List, Optional

import pandas as pd
import tabula

# --------------------------------------------------------------------------- #
# 1. Nombres y columnas estándar
# --------------------------------------------------------------------------- #
COLUMN_NAMES: List[str] = [
    "product_number", "formula_code", "product_name", "product_form",
    "unit_weight", "pallet_quantity", "stocking_status", "min_order_quantity",
    "days_lead_time", "fob_or_dlv", "price_change", "list_price",
    "full_pallet_price", "half_load_full_pallet_price",
    "full_load_full_pallet_price", "full_load_best_price",
]
NUMERIC_COLS = COLUMN_NAMES[10:]

# --------------------------------------------------------------------------- #
# 2. Conversión numérica (corrige ‘100‑’ → -100)
# --------------------------------------------------------------------------- #
def _to_float(val):
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    s = str(val).strip()
    if not s:
        return None
    sign = -1 if s.endswith("-") else 1
    if sign == -1:
        s = s[:-1]
    try:
        return float(s) * sign
    except ValueError:
        return None


def _fix_numeric(df: pd.DataFrame) -> pd.DataFrame:
    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = df[col].apply(_to_float)
    return df

# --------------------------------------------------------------------------- #
# 3. Metadatos: fecha efectiva y planta
# --------------------------------------------------------------------------- #
DATE_RX = re.compile(r"\d{1,2}/\d{1,2}/(\d{4}|\d{2})")
LOC_RX = re.compile(r"([A-Z]+\s*'?[A-Z]*S?)")


def _first_table(pdf, area) -> Optional[str]:
    """Extrae un pequeño bloque de texto para buscar fecha o ubicación."""
    try:
        tbls = tabula.read_pdf(
            pdf, pages=1, area=area, lattice=True, guess=False,
            pandas_options={"dtype": str, "header": None})
        return str(tbls[0]) if tbls else None
    except Exception:
        return None


def effective_date(pdf):
    text = _first_table(pdf, [50, 0, 200, 400])
    if not text:
        return None
    m = DATE_RX.search(text)
    if not m:
        return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            return _dt.datetime.strptime(m.group(0), fmt).date().isoformat()
        except ValueError:
            pass
    return None


def plant_location(pdf):
    text = _first_table(pdf, [0, 0, 50, 250])
    if not text:
        return None
    text = text.upper()
    if "HUDSON'S" in text:
        return "HUDSON'S"
    m = LOC_RX.search(text)
    return m.group(1) if m else None

# --------------------------------------------------------------------------- #
# 4. Detección de filas‑cabecera / fragmentos
# --------------------------------------------------------------------------- #
HEADER_TOKENS = {
    "PRODUCT", "FORM", "UNIT", "WEIGHT", "PALLET", "MIN", "ORDER",
    "QUANTITY", "DAYS", "LEAD", "TIME", "STOCKING", "STATUS", "FOB", "DLV",
}
PRICE_HEADER_PATTERNS = (
    "PRICE / UNIT",
    "PRICE IN US DOLLAR",   # sin ‘S’ (algunas hojas vienen así)
    "PRICE IN US DOLLARS",
    "MONTHLY",
    "PAGE",                 # “Page 2 of 13”
)

# pre‑compilado para búsqueda más rápida en toda la fila
_PRICE_RE = re.compile("|".join(re.escape(p) for p in PRICE_HEADER_PATTERNS), re.I)


def _is_header_row(row: pd.Series) -> bool:
    """
    Devuelve True si la fila es cabecera, fragmento o basura.
    Se revisa la primera celda **y** el contenido combinado de la fila para
    cubrir casos como “Price in US Dollars” en medio de la tabla.
    """
    # --- 1. ¿Contiene algún patrón prohibido en cualquier columna?
    combined = " ".join(str(x).upper() for x in row if x and not pd.isna(x))
    if _PRICE_RE.search(combined):
        return True

    # --- 2. Reglas clásicas (primera celda) ------------------------------
    first = str(row.iloc[0]).strip().upper()

    # no eliminar si comienza por dígito (fila de datos)
    if first and first[0].isdigit():
        return False

    # Cabecera principal
    if first.startswith("PRODUCT") and str(row.iloc[1]).upper().startswith("FORMULA"):
        return True

    # Fragmentos (MIN / DAYS etc.) – sólo si no tienen precios
    if pd.isna(row["list_price"]):
        if any(tok in combined for tok in HEADER_TOKENS):
            return True

    return False

# --------------------------------------------------------------------------- #
# 5. Lectura y estandarización de tablas
# --------------------------------------------------------------------------- #
def _read_tables(pdf):
    """Lee todas las tablas con lattice, sin asumir cabecera."""
    try:
        return tabula.read_pdf(
            pdf,
            pages="all",
            lattice=True,
            guess=False,
            pandas_options={"dtype": str, "header": None},  # <- clave
        )
    except Exception as exc:
        print("[tabula]", exc)
        return []


def _standardize(tbl: pd.DataFrame):
    """Recorta a 16 columnas y aplica nombres estándar."""
    if tbl.shape[1] < 16:
        return None
    out = tbl.iloc[:, :16].copy()
    out.columns = COLUMN_NAMES
    return out

# --------------------------------------------------------------------------- #
# 6. Función principal
# --------------------------------------------------------------------------- #
def read_file(pdf: str | pathlib.Path) -> pd.DataFrame:
    tables = _read_tables(str(pdf))
    std_tables = [t for t in (_standardize(x) for x in tables) if t is not None]
    if not std_tables:
        return pd.DataFrame()

    df = pd.concat(std_tables, ignore_index=True)

    # eliminar cabeceras / fragmentos pero conservar la primera fila de datos
    df = df[~df.apply(_is_header_row, axis=1)].reset_index(drop=True)
    df.dropna(how="all", inplace=True)

    # metadatos
    df["plant_location"] = plant_location(pdf)
    df["date_inserted"] = effective_date(pdf)
    df["source"] = "pdf"

    return _fix_numeric(df)[[*COLUMN_NAMES, "plant_location", "date_inserted", "source"]]

# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------
